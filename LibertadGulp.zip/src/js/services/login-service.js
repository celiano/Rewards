app.factory('Login', ['$http', function ($http) {
	
		var login = {};
		var baseUrl = "http://localhost:45513";
		var apiName = "/api/Login";

		login.logear = function (data) {
			// console.log(baseUrl + apiName + "?usuario=" + data.usuario + "&clave=" + data.password);
			return $http.get(baseUrl + apiName + "?usuario=" + data.usuario + "&clave=" + data.password);
		}
		return login;
	}
])